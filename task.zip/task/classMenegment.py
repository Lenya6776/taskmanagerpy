from dataclasses import dataclass
import json

@dataclass
class Menegment:
    name : str = 'Anton'
    tasklist = []
    numbertask = 0
    @property
    def meet(self):
        return f"Привет, {self.name}!\nЭто консольный менеджер задач." \
        "\nМеню для ввода:\n1) добавить задачу\n2) показать все" \
        "\n3) отметить выполненной\n4) удалить\n0) выход\n"

    def __post_init__(self):
        try:
            with open("tasks.json", "r", encoding="utf-8") as f:
                self.tasklist = json.load(f)
        except Exception:
            self.tasklist = []
    
    def add(self):
        print("Введите вашу задачу:")
        task = input()
        self.tasklist.append({task: "Ждёт выполнения"})
        self.save_json()
        print("Ваша задача добавлена!")
    
    def viem(self):
        if len(self.tasklist) >= 1:
            print("Вот список ваших задач:")
            i = 1
            for task in self.tasklist:
                name = list(task.keys())[0]
                print(f"{i}) {name}: {task[name]}")
                i += 1
        else:
            print("У вас нет задач!")

    def choice(self):
        if len(self.tasklist) >= 1:
            print("Введите порядковый номер: ")
            try:
                self.numbertask = int(input())
                if self.numbertask > len(self.tasklist) or self.numbertask < 1:
                    raise IndexError
                return True
            except (ValueError, IndexError):
                print("Введите порядковый номер задачи цифрами!")
                return False
        else:
            print("У вас нет задач!")
    
    def note(self):
        if self.choice():
            task = self.tasklist[self.numbertask - 1]
            keys = list(task.keys())
            task[keys[0]] = "Выполнено"
            self.save_json() 

    def delete(self):
        if self.choice():
            self.tasklist.pop(self.numbertask - 1)
            self.save_json()

    def save_json(self):
        with open("tasks.json", "w", encoding="utf-8") as f:
            json.dump(self.tasklist, f, ensure_ascii=False, indent=2)
from classMenegment import Menegment

def main():
    user = Menegment()
    print(user.meet)
    isopen = True
    while isopen:
        print("Введите что вам нужно: ")
        try:
            x = int(input())
            match x:
                case 1:
                    user.add()
                case 2:
                    user.viem()
                case 3:
                    user.note()
                case 4:
                    user.delete()
                case 0:
                    isopen = False
                    print("До свидания!")
                case _:
                    print("Нет такой команды!")
        except (ValueError):
            print("Введите число!")

if __name__ == "__main__":
    main()